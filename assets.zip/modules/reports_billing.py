import sqlite3
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton
from PyQt5.QtPrintSupport import QPrinter, QPrintDialog
from PyQt5.QtGui import QPainter

from database.db_config import DB_PATH


class BillingReport(QWidget):
    def __init__(self, embed=False):
        super().__init__()
        layout = QVBoxLayout(self)

        self.table = QTableWidget()
        layout.addWidget(self.table)

        export_btn = QPushButton("Print / Export PDF")
        export_btn.clicked.connect(self.export_pdf)
        layout.addWidget(export_btn)

        self.load_data()

    def load_data(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT b.id, p.name AS patient_name, b.doctor_name, b.total_amount
            FROM billing b
            LEFT JOIN patients p ON b.patient_id = p.id
            ORDER BY b.id DESC
        """)
        rows = cursor.fetchall()
        conn.close()

        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID", "Patient Name", "Doctor", "Total Amount"])
        self.table.setRowCount(len(rows))

        for r, row in enumerate(rows):
            for c, col in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(str(col)))

    def export_pdf(self):
        printer = QPrinter(QPrinter.HighResolution)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName("billing_report.pdf")
        painter = QPainter()
        painter.begin(printer)
        self.table.render(painter)
        painter.end()
