from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QComboBox, QPushButton, QLineEdit, QTableWidget, QTableWidgetItem, QFormLayout, QMessageBox
from PyQt5.QtCore import Qt
import sqlite3
import os
from database.db_config import DB_PATH
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

class BillingModule(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        form_layout = QFormLayout()

        self.patient_combo = QComboBox()
        self.load_patients()
        form_layout.addRow("Patient:", self.patient_combo)

        self.doctor_combo = QComboBox()
        self.load_doctors()
        form_layout.addRow("Doctor:", self.doctor_combo)

        self.treatment_input = QLineEdit()
        form_layout.addRow("Treatment Description:", self.treatment_input)

        self.amount_input = QLineEdit()
        form_layout.addRow("Amount (INR):", self.amount_input)

        self.add_button = QPushButton("Generate Bill")
        self.add_button.clicked.connect(self.generate_bill)
        form_layout.addWidget(self.add_button)

        layout.addLayout(form_layout)

        self.bills_table = QTableWidget()
        self.bills_table.setColumnCount(4)
        self.bills_table.setHorizontalHeaderLabels(["Patient", "Doctor", "Treatment", "Amount"])
        layout.addWidget(QLabel("Generated Bills:"))
        layout.addWidget(self.bills_table)

        self.setLayout(layout)
        self.init_db()
        self.load_bills()

    def init_db(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bills (
                bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_name TEXT,
                doctor TEXT,
                treatment TEXT,
                amount REAL
            )
        """)
        conn.commit()
        conn.close()

    def load_patients(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT patient_id, name FROM patients")
        patients = cursor.fetchall()
        self.patient_combo.clear()
        for pid, name in patients:
            self.patient_combo.addItem(f"{name} (ID:{pid})", pid)
        conn.close()

    def load_doctors(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT DISTINCT doctor FROM appointments WHERE doctor IS NOT NULL")
            doctors = [row[0] for row in cursor.fetchall() if row[0]]
            self.doctor_combo.clear()
            self.doctor_combo.addItems(doctors)
        except sqlite3.OperationalError:
            self.doctor_combo.clear()
            self.doctor_combo.addItem("Neethu Mathew")  # fallback
        finally:
            conn.close()

    def generate_bill(self):
        patient = self.patient_combo.currentText()
        doctor = self.doctor_combo.currentText()
        treatment = self.treatment_input.text()
        amount = self.amount_input.text()

        if not all([patient, doctor, treatment, amount]):
            QMessageBox.warning(self, "Input Error", "Please fill in all fields.")
            return

        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO bills (patient_name, doctor, treatment, amount)
                VALUES (?, ?, ?, ?)
            """, (patient, doctor, treatment, amount))
            conn.commit()
            conn.close()

            self.load_bills()
            self.generate_pdf_invoice(patient, doctor, treatment, amount)
            QMessageBox.information(self, "Success", "Bill saved and PDF generated.")
        except Exception as e:
            QMessageBox.critical(self, "Database Error", str(e))

    def load_bills(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT patient_name, doctor, treatment, amount FROM bills")
        bills = cursor.fetchall()
        conn.close()

        self.bills_table.setRowCount(0)
        for row_idx, row_data in enumerate(bills):
            self.bills_table.insertRow(row_idx)
            for col_idx, col_data in enumerate(row_data):
                self.bills_table.setItem(row_idx, col_idx, QTableWidgetItem(str(col_data)))

    def generate_pdf_invoice(self, patient, doctor, treatment, amount):
        pdfmetrics.registerFont(UnicodeCIDFont("HeiseiMin-W3"))
        file_path = os.path.join(os.getcwd(), f"Invoice_{patient.replace(' ', '_')}.pdf")
        doc = SimpleDocTemplate(file_path, pagesize=A4)
        styles = getSampleStyleSheet()
        story = []

        header = Paragraph("<b>Dr. N's Dental Studio</b><br/>"
                           "First Floor, Chovattukunnel Plaza,<br/>"
                           "Erattupetta Road, Edappady, Pala,<br/>"
                           "Bharananganam, Kerala 686578", styles['Title'])
        story.append(header)
        story.append(Spacer(1, 0.25 * inch))

        details = f"""
        <b>Patient:</b> {patient}<br/>
        <b>Doctor:</b> {doctor}<br/>
        <b>Treatment:</b> {treatment}<br/>
        <b>Amount:</b> ₹ {amount}<br/>
        """
        story.append(Paragraph(details, styles['Normal']))

        doc.build(story, onFirstPage=self.add_watermark)

    def add_watermark(self, canvas, doc):
        try:
            logo_path = os.path.join(os.getcwd(), "DrWs_Dental_Studio_Icon.ico")
            if os.path.exists(logo_path):
                canvas.saveState()
                canvas.drawImage(ImageReader(logo_path), x=450, y=750, width=80, height=80, mask='auto')
                canvas.restoreState()
        except Exception as e:
            print("Logo error:", e)
