from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QFormLayout, QHBoxLayout, QComboBox, QMessageBox
from PyQt5.QtCore import Qt
import sqlite3
from database.db_config import DB_PATH

class AppointmentsModule(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()

        # Form to add appointments
        form_layout = QFormLayout()

        self.patient_combo = QComboBox()
        self.load_patients()
        form_layout.addRow("Patient:", self.patient_combo)

        self.doctor_combo = QComboBox()
        self.doctor_combo.addItems(["Neethu Mathew", "Dr. Smith", "Dr. Thomas"])  # You can extend this
        form_layout.addRow("Doctor:", self.doctor_combo)

        self.date_input = QLineEdit()
        form_layout.addRow("Date (YYYY-MM-DD):", self.date_input)

        self.time_input = QLineEdit()
        form_layout.addRow("Time (HH:MM):", self.time_input)

        self.reason_input = QLineEdit()
        form_layout.addRow("Reason:", self.reason_input)

        self.add_button = QPushButton("Add Appointment")
        self.add_button.clicked.connect(self.add_appointment)
        form_layout.addWidget(self.add_button)

        layout.addLayout(form_layout)

        # Table to show appointments
        self.appointments_table = QTableWidget()
        self.appointments_table.setColumnCount(6)
        self.appointments_table.setHorizontalHeaderLabels(["ID", "Patient", "Doctor", "Date", "Time", "Reason"])
        layout.addWidget(QLabel("Appointments:"))
        layout.addWidget(self.appointments_table)

        self.setLayout(layout)
        self.load_appointments()

    def load_patients(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT patient_id, name FROM patients")
        patients = cursor.fetchall()
        self.patient_combo.clear()
        for pid, name in patients:
            self.patient_combo.addItem(f"{name} (ID:{pid})", pid)
        conn.close()

    def add_appointment(self):
        patient_id = self.patient_combo.currentData()
        doctor = self.doctor_combo.currentText()
        date = self.date_input.text()
        time = self.time_input.text()
        reason = self.reason_input.text()

        if not all([patient_id, doctor, date, time, reason]):
            QMessageBox.warning(self, "Input Error", "Please fill in all fields.")
            return

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO appointments (patient_id, doctor, date, time, reason)
            VALUES (?, ?, ?, ?, ?)
        """, (patient_id, doctor, date, time, reason))
        conn.commit()
        conn.close()

        QMessageBox.information(self, "Success", "Appointment added successfully.")
        self.load_appointments()

    def load_appointments(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT a.appointment_id, p.name, a.doctor, a.date, a.time, a.reason
            FROM appointments a
            JOIN patients p ON a.patient_id = p.patient_id
        """)
        appointments = cursor.fetchall()
        self.appointments_table.setRowCount(0)

        for row_idx, row_data in enumerate(appointments):
            self.appointments_table.insertRow(row_idx)
            for col_idx, col_data in enumerate(row_data):
                self.appointments_table.setItem(row_idx, col_idx, QTableWidgetItem(str(col_data)))

        conn.close()
